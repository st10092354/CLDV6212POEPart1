﻿using Azure.Storage.Queues;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace AbcRetail.Services
{
    public class QueueService
    {
        private readonly QueueServiceClient _queueServiceClient;

        // this constructor initializes the QueueServiceClient using the connection string from configuration
        public QueueService(IConfiguration configuration)
        {
            _queueServiceClient = new QueueServiceClient(configuration["AzureStorage:ConnectionString"]);
        }

        // this method is to send a message to the specified Azure Queue
        public async Task SendMessageAsync(string queueName, string message)
        {
            var queueClient = _queueServiceClient.GetQueueClient(queueName);
            await queueClient.CreateIfNotExistsAsync(); // this ensures that the queue exists
            await queueClient.SendMessageAsync(message); // this sends the message to the queue
        }
    }
}
