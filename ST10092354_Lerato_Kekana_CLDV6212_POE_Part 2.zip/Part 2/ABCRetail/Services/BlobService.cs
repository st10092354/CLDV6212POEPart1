﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Threading.Tasks;

namespace AbcRetail.Services
{
    public class BlobService
    {
        private readonly BlobServiceClient _blobServiceClient;

        // this constructor initializes the BlobServiceClient using the connection string from the configuration
        public BlobService(IConfiguration configuration) => _blobServiceClient = new BlobServiceClient(configuration["AzureStorage:ConnectionString"]);

        // this method is to upload a blob to the specified container in Azure Blob Storage
        public async Task UploadBlobAsync(string containerName, string blobName, Stream content)
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            await containerClient.CreateIfNotExistsAsync(); // checks if the container exists
            var blobClient = containerClient.GetBlobClient(blobName);
            await blobClient.UploadAsync(content, true); // this uploads the content to the blob
        }
    }
}
